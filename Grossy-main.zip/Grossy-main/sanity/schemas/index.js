import vegies from './vegies'


export const schemaTypes = [
  // Document types
  vegies
]
