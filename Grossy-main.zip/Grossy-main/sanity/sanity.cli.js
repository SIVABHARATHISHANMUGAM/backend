import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 't6oolyxc',
    dataset: 'production'
  }
})
