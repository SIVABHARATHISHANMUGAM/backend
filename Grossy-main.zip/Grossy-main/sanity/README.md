# Sanity Movies Content Studio

- Backend api data for our  vegetables/ greens powered by sanity studio
