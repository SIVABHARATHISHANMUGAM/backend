import Layout from '../../components/Layout';

export default function Vegie({vegie}) {
  return (
    <Layout>
       Individual vegie item page
    </Layout>
  )
};